package Program_Practice_9_10_2022;

public class Print_1_To_100 {
	public static void main(String [] agrs) {
		
		int n=1;
		while(n<=100) {
			System.out.println(n++);
			
		}
	}

}
