package Program_Practice_9_10_2022;

public class Print_100_To_1 {
	
	public static void main(String [] agrs) {
		
		int n=100;
		
		while(n>=1) {
			System.out.println(n--);
		}
		
	}

}
