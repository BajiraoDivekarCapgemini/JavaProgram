package Program_Practice_9_10_2022;

public class Reverse_Number {
	
	
	public static int reverseNumber(int n) {
		
		int rev=0;
		int rem;
		while(n>0) {
			rem=n%10;
			rev=rev*10+rem;
			n=n/10;
			}
		return rev;
		}
	
	public static void main(String [] agrs) {
		
		System.out.println(reverseNumber(123456));
		
	}

}
