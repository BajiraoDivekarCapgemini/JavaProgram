package Program_Practice_9_10_2022;

import java.util.Arrays;

public class Sorting_Of_Array {
	
	public static void main(String [] agrs) {
		
		
		int [] a= {10,5,4,3,20,15,25};
		
		Arrays.sort(a);
		
		System.out.println(Arrays.toString(a));
		
	}

}
