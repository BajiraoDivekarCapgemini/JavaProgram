package Program_Practice_9_10_2022;

public class Occurance_Of_Charactor {
	public static void main(String[] args) {
		
		
		String s="ababac";
		
		for(int i=0;i<=s.length()-1;i++) {
			int count=1;
			char ch=s.charAt(i);
			for(int j=i+1;j<=s.length()-1;j++){
				char ch1=s.charAt(j);
				if(ch==ch1 && ch1!=' ') {
					count++;
					ch1='0';
				}
				
			}
			if(ch!='0') {
				System.out.println(ch+" = "+count);
			
		}
		
		
			
		}
		
		
		
	}


}
