package Program_Practice_30_09_2022;

public class Print_1_To_100 {
	public static void main(String [] args) {
		
		//print 1 to 100
		/*int i=1;
		while(i<=100) {
			System.out.println(i++);
		}
		*/
		
		//print 100 to 1
		
		/*int n=100;
		
		while(n>=1) {
			System.out.println(n--);
		}*/
		
		
		// Print char A to Z
		
		char ch='A';
		
		while(ch<='Z') {
			System.out.println(ch++);
		}
		
	}

}
