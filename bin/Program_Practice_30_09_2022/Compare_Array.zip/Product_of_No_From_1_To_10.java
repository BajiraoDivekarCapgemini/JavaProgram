package Program_Practice_30_09_2022;

public class Product_of_No_From_1_To_10 {
	
	public static void main(String []args) {
		
		/*int n=1;
		int product=1;
		while(n<=5) {
			product=product*n;
			n++;
			}
		System.out.println(product);
		*/
		int prod=1;
		for(int n=1;n<=5;n++) {
			
			prod=prod*n;
		}
		System.out.println(prod);
		
		
	}
		
	

}
