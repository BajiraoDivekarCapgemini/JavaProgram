package Program_Practice_30_09_2022;

public class Print_Even_Number_From_1_To_100 {

	public static void main(String[] args) {
	
		
		/*for(int i=1;i<=50;i++) {
			
			if(i%2==0) {
				System.out.println(i);
			}
			
		}*/
		
		int num=1;
		while(num<=50) {
			if(num%2==0) {
				System.out.println(num);
			}
			num++;
			
		}
		
	}

}
